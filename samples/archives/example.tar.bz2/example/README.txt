Sample archive for Everything Viewer
====================================

This archive is self-made and in the public domain (CC0-1.0).
It contains three small text files in two folders.
Accented letters to check the character encoding: café naïve Zürich €
