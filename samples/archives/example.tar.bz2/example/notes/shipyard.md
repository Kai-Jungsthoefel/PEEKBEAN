# Notes

- Hull: steel, superstructure: aluminium
- Length overall: 42.5 m
- Next date: sea trial
